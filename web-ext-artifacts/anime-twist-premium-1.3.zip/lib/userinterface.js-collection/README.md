# userinterface.js-collection [![Build Status](https://travis-ci.com/thoughtsunificator/userinterface.js-collection.svg?branch=master)](https://travis-ci.com/thoughtsunificator/userinterface.js-collection)

userinterface.js-collection is a collection of UI elements to help build your UI. In this collection you will find ready to use tabs, input, button etc.

## Getting Started

### Prerequisites

- [userinterface.js](https://github.com/thoughtsunificator/userinterface.js)

### Installing

Run ```git submodule add https://github.com/thoughtsunificator/userinterface.js-collection.git lib/userinterface.js-collection``` at the root of your project.

userinterface.js-collection should be located in the `lib/` folder at the root of your project.

### Usage

```html
<!DOCTYPE html>
<html>
<head>
	<script src="./lib/userinterface.js/src/userinterface.js" type="text/javascript"></script>
	<script src="./lib/userinterface.js-collection/userinterface/button.js" type="text/javascript"></script>
</head>
<body>
	<script>
		const application = {}
		UserInterface.runModel("collection.button", { parentNode: document.body, bindingArgs: [application, { action: "foo" }], data: { text: "Button #1" } })
	</script>
</body>
</html>
```

## Collection

### Control

Controls are a type of element that when interacted with emit a certain event to a given context.

Base Prototype: ```function(string action)```

* Controls are customizable, you can pass ``style`` and ``className`` to customize the look of the model through the ``data`` parameter.
````javascript
UserInterface.runModel("collection.button", { parentNode: document.body, bindingArgs: [application, { action: "foo" }], data: { text: "Button #1", className: "myButton" } })
````

#### collection.button

Prototype: ```function(* application, Control control)```

Parameters:
- ```active``` - If true the button will be set to active when a certain event is announced.

#### collection.input

Prototype: ```function(* application, Control control)```

#### collection.resizable

Prototype: ```function(* application, Control control)```

Parameters:
- ```directions```  Can be horizontal, diagonal, vertical or all three.
- ```preview```     If true, will show a selection rectangle that moves indicating the new size of the target

#### collection.select

Prototype: ```function(* application, Control control)```

#### collection.tab

Prototype: ```function(* application, Control control)```

Parameters:
- ```name```   The name of the tab that will be passed to the event listeners.
- ```toggle``` If true the event will be announced even if the tab is already selected.

### collection.popup

Coming soon...

#### collection.popup_form

Coming soon..

#### collection.popup_controls

Coming soon..

#### collection.popup_confirm

Coming soon..

## Running the tests

Run ``npm install``

Then simply run ``npm test`` to run the tests.